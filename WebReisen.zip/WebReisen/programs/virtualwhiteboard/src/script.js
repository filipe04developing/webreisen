
//sets the canvas and intial size of the canvas
const canvas = document.getElementById("whiteboard");
const board = canvas.getContext("2d"); //context (ctx)
resizeCanvas();

//sets the intial position of the mouse
let pos = { x: 0, y: 0 };

//gets the buttons for color/eraser/etc.
let color = "black";
let paintStroke = 10;
let eraser = document.getElementById("eraserBtn");
let clear = document.getElementById("reset");
let pinkDraw = document.getElementById("drawBtnPink");
let yellowDraw = document.getElementById("drawBtnYellow");
let blueDraw = document.getElementById("drawBtnBlue");

//event listeners to trigger functions on mouse/window events
document.addEventListener("resize", resizeCanvas);
document.addEventListener("mousedown", setPosition);
document.addEventListener("mouseenter", setPosition);
document.addEventListener("mousemove", paint);

//event listeners for buttons 
eraser.addEventListener("mousedown", erase);
clear.addEventListener("mousedown", reset)
pinkDraw.addEventListener("mousedown", drawInPink);
yellowDraw.addEventListener("mousedown",drawInYellow);
blueDraw.addEventListener("mousedown", drawInBlue);

function resizeCanvas() {
  //resizes the canvas when window changes
  board.canvas.width = 1200;
    // window.innerWidth;
  board.canvas.height = 500;
    // window.innerHeight;
}

function setPosition(e) {
  //sets the mouse position each time it moves / clicks 
  pos.x = e.clientX;
  pos.y = e.clientY;
}

function paint(e) {
  //handles the "painting" on the canvas 
  if(e.buttons != 1) {
    return;
  }
  //sets the lines properties and color 
  board.beginPath();
  board.lineWidth = paintStroke;
  board.lineCap = "round";
  board.strokeStyle = color;
  
  //handles the lines position 
  board.moveTo(pos.x, pos.y);
  setPosition(e);
  board.lineTo(pos.x, pos.y);
  
  //draws the line
  board.stroke();
}

function erase() {
  color = "black";
  paintStroke = 200;
}

function drawInPink() {
  color = "#ff8282";
  paintStroke = 10;
}

function drawInBlue() {
  color = "#a8ecf0";
  paintStroke = 10;
}

function drawInYellow() {
  board.lineCap = "butt";
  color = "#fcfb95";
  paintStroke = 10;
}

function reset() {
  //clears the canvas
  board.clearRect(0,0,canvas.width,canvas.height);
}
